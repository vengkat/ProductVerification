package com.wss.productverification;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SuccessActivity extends Activity{
	private Button back_button;
	private TextView success_msg;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_success);
		
		back_button = (Button)findViewById(R.id.back_button);
		success_msg = (TextView)findViewById(R.id.success_msg);
		success_msg.setText("Genuine AbbVie Product");
		back_button.setOnClickListener(new OnClickListener() {

		    public void onClick(View v) {
			    //Toast toast = Toast.makeText(getApplicationContext(), 
				//        "Back Button Clicked!", Toast.LENGTH_SHORT);
				//    toast.show();
				    GoHome();
		    }
		 });
		
	}
	
	public void GoHome() {
		Intent intent = new Intent(SuccessActivity.this,MainActivity.class);
 		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
 		startActivity(intent);
	}
	
    @Override
    public void onBackPressed() {
    	GoHome();
    } 
}
